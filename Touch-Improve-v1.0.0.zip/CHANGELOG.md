<h1 align="center">Changelog</h1>

### Version 1.0.0 (Release Build)

- Add sliding response
- Add global touch response
- Release version 1.0.0

### Version 1.0.2-Beta

- Add new touch improve variable
- Add touch pressure
- Add any code to improve touch sampling rate

### Version 1.0.1-Beta

- Change Update-binary file

### Version 1.0-Beta

- Initial Build
